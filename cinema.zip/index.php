<?php 
header('Location:views/file/home.php');
?>