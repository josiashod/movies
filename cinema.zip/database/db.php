<?php 
    $bdd = new PDO('mysql:host=localhost;dbname=cinema', 'root', '');
?>
